#!/bin/bash

USR_EX=$1
pkill -u $USR_EX