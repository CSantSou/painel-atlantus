<?php

        date_default_timezone_set('America/Sao_Paulo');
        ini_set('error_reporting', 1);
        define('DB_SERVER', 'localhost');
        define('DB_USERNAME', '');
        define('DB_PASSWORD', '');
        define('DB_NAME', '');
        try {
            $pdo = new PDO("mysql:host=" . DB_SERVER . ";dbname=" . DB_NAME, DB_USERNAME, DB_PASSWORD);
            $pdo -> exec("set names utf8");
          } catch(PDOException $e) {
            die("Falha ao conectar no banco de dados.");
        }
        $license = "license";
        $security = "security";
        
        ?>
    