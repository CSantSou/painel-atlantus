#!/bin/bash
USR_EX=$1
pkill -u $USR_EX && deluser $USR_EX
pkill -u $USR_EX && userdel $USR_EX